def calc_sum():
    a = int(input("Enter a = "))
    b = int(input("Enter b = "))
    res = a + b
    print(f"c = %d + %d = %d" % (a, b, res))


if __name__ == "__main__":
    calc_sum()
    